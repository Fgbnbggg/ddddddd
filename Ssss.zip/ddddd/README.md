<p align="center"><a href="https://t.me/V_I_DE_bot"><img src="https://github.com/levina-lab/video-stream/raw/main/driver/veezlogo.png"></a></p>
<p align="center">
    <br><b>فـيـديـو مـبـاشـر هـو بـوت تـرقـيـه الـمـتـقـدم الـذي يـسـمـح لـك بـتـشـغـيـل الفيديو والـمـوسـيـقـى على رومـات الـتـيـلـيـجـرام</b><br>
</p>
<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>
    <a href="https://github.com/levina-lab/video-stream/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-red.svg?style=flat-square" /></a>
    <a href="https://app.codacy.com/gh/levina-lab/video-stream/dashboard"> <img src="https://img.shields.io/codacy/grade/a723cb464d5a4d25be3152b5d71de82d?color=red&logo=codacy&style=flat-square" alt="Codacy" /></a><br>
    <a href="https://github.com/levina-lab/video-stream"> <img src="https://img.shields.io/github/repo-size/levina-lab/video-stream?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/levina-lab/video-stream/commits/main"> <img src="https://img.shields.io/github/last-commit/levina-lab/video-stream?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/levina-lab/video-stream/issues"> <img src="https://img.shields.io/github/issues/levina-lab/video-stream?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/levina-lab/video-stream/network/members"> <img src="https://img.shields.io/github/forks/levina-lab/video-stream?color=red&logo=github&logoColor=blue&style=flat-square" /></a>  
    <a href="https://github.com/levina-lab/video-stream/network/members"> <img src="https://img.shields.io/github/stars/levina-lab/video-stream?color=red&logo=github&logoColor=blue&style=flat-square" /></a>  
</p>

## 📊 احصائيات
[![CodeFactor](https://www.codefactor.io/repository/github/levina-lab/video-stream/badge)](https://www.codefactor.io/repository/github/levina-lab/video-stream)

## 🧪 كود الجلسه احصل على `SESSION_NAME` from below:

[![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@levinalab/StringSession#main.py) ``Pyrogram``

## 🎭 معاينة
<p align="center">
  <img src="https://telegra.ph/file/924bde9bda30db3246eec.jpg">
</p>

## ✨ دعم دفق الموسيقى والفيديو

دعم MultiChat

دعم قائمة التشغيل وقائمة الانتظار

ميزة تخطي ، وقفة ، واستئناف ، وإيقاف

ميزة تنزيل الموسيقى والفيديو

دعم البحث المضمن

يوتيوب دعم البحث المباشر

دعم دفق YouTube / Local / Live / m3u8

دعم البحث المضمن

التحكم مع دعم الزر

التحكم في مستوى الصوت

الانضمام التلقائي إلى Userbot

محدث مباشر

🛠 الأوامر:

CommandDescription / mplay (استعلام) تشغيل الموسيقى من youtube / vplay (استعلام) تشغيل الفيديو من youtube / vstream (رابط مباشر) تشغيل فيديو بث مباشر / إيقاف مؤقت للبث (المسؤول فقط) / استئناف البث (المسؤول فقط) / skipswitch إلى التالي دفق (المشرف فقط) / إيقاف البث (المسؤول فقط) / vmut لكتم صوت userbot على الدردشة الصوتية / vunmut لإلغاء كتم صوت userbot في الدردشة الصوتية / المجلد 1/200 ، اضبط حجم برنامج userbot (يجب أن يكون userbot مسؤولاً) / playlists تظهر لك كل الحالي قائمة الدفق / الأغنية (استعلام) تنزيل الموسيقى من youtube / video (استعلام) تنزيل الفيديو من youtube / userbotjoin قم بدعوة userbot للانضمام إلى المجموعة (المسؤول فقط) / userbotleavein إرشاد userbot لمغادرة المجموعة (المسؤول فقط) / اترك الأمر userbot لمغادرة الكل group (sudo only) / قم بتحديث الروبوت الخاص بك مباشرة دون مغادرة telegram (sudo فقط) / أعد تشغيل الروبوت الخاص بك مباشرة دون مغادرة telegram (sudo فقط) / cleanclean all raw files / rmdclean all download files

انتشار Heroku 💜

الطريقة السهلة لاستضافة هذا الروبوت ، والنشر في Heroku ، وتغيير بلد التطبيق إلى أوروبا (سيساعد ذلك في جعل الروبوت مستقرًا).

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/levina-lab/video-stream)

## نشر VPS 📡
احصل على أفضل جودة لأداء البث من خلال استضافته على VPS ، وإليك الخطوات:

ش
تحديث sudo apt && apt Upgrade -y
sudo apt install git curl python3-pip ffmpeg -y
تثبيت pip3 -U pip
curl -sL https://deb.nodesource.com/setup_16.x | باش -
sudo apt-get install -y nodejs
npm i -g npm
git clone https://github.com/levina-lab/video-stream # استنساخ الريبو.
سي دي دفق الفيديو
تثبيت pip3 -U -r requirements.txt
cp example.env .env # استخدم vim لتحرير ENVs
vim .env # قم بملء ENVs (الخطوات: اضغط على i للدخول في وضع الإدراج ثم قم بتحرير الملف. اضغط Esc للخروج من وضع التحرير ثم اكتب: wq! واضغط على مفتاح Enter لحفظ الملف).
python3 main.py # قم بتشغيل البوت.

# تابع المضيف بالشاشة أو أي شيء آخر ، شكرًا على القراءة.
```

# الاعتمادات 💖

- [desha](https://github.com/MostafaShalaby1) ``Dev``
- [Zxce3](https://github.com/Zxce3) ``Dev``
- [DoellBarr](https://github.com/DoellBarr) ``Dev``
- [tofikdn](https://github.com/tofikdn) ``Dev``
- [Hunter-XDD](https://github.com/Hunter-XDD) ``Dev``
- [Laky's](https://github.com/Laky-64) for [``py-tgcalls``](https://github.com/pytgcalls/pytgcalls)
- [Dan](https://github.com/delivrance) for [``Pyrogram``](https://github.com/pyrogram)

### يدعم & التحديثات 🎑
<a href="https://t.me/music_Desha"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/music_Desha1"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
